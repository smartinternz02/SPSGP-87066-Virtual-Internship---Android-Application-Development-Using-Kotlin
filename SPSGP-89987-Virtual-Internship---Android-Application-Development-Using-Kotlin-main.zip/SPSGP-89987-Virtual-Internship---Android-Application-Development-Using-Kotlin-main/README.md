# SPSGP-89987-Virtual-Internship---Android-Application-Development-Using-Kotlin
Virtual Internship - Android Application Development Using Kotlin

This repository contains the code for Grocery App made as the project submission for this internship.

### Screenshot
<img src="https://github.com/smartinternz02/SPSGP-89987-Virtual-Internship---Android-Application-Development-Using-Kotlin/blob/main/app/src/main/res/screenshots/Screenshot_20220925_174335.png" width="290" alt="Splash Screen" /> <img src="https://github.com/smartinternz02/SPSGP-89987-Virtual-Internship---Android-Application-Development-Using-Kotlin/blob/main/app/src/main/res/screenshots/Screenshot_20220925_174441.png" width="290" alt="Insert Dialog" /> 

<img src="https://github.com/smartinternz02/SPSGP-89987-Virtual-Internship---Android-Application-Development-Using-Kotlin/blob/main/app/src/main/res/screenshots/Screenshot_20220925_175036.png" width="290" alt="Insert Item" /> <img src="https://github.com/smartinternz02/SPSGP-89987-Virtual-Internship---Android-Application-Development-Using-Kotlin/blob/main/app/src/main/res/screenshots/Screenshot_20220925_175055.png" width="290" alt="Delete Item" />

### Demo Video
[![Demo Video](https://yt-embed.herokuapp.com/embed?v=8LQLkdQzy2U)](https://www.youtube.com/watch?v=8LQLkdQzy2U "Demo Video")
